//program1.cpp 
//Simple stream input and output
//hello.cpp
#include <iostream>

using std::cout;
using std::cin;

main()
{
	//Hello world part
	cout << "Hello c++ on Titania.\n";

	//User input and output
	float a, b;
        cout << "Enter two floating point numbers a and b.\n";


        //Output from one operation can be input into the
        //next operation. (Many indirection operators can 
        //appear on a single statement line).
	cin >> a >> b;
	cout << a << " + " << b << " is " << a+b << "\n";

	return 0;
}


