//program13.cpp
//Using namespaces example

#include <iostream.h>

namespace first
{
	int var=5;
}

namespace second
{
	double var=3.141;
}

int main()
{
	cout << "Namespace first " << first::var << endl;
	cout << "Namespace second " << second::var << endl;

	{
		using namespace first;
		cout << "Using namespace first " << var << endl;		
	}

	{
		using namespace second;
		cout << "Using namespace second " << var << endl;
	}

	return 0;
}
