//program14.h
//Point class
//An example of ineritance

#include "point14.hpp"


//point class methods
point::point(float x, float y)
{
  //Default constructor
  m_x=x;
  m_y=y;
}

void point::setpoint(float x, float y)
{
  m_x=x;
  m_y=y;
}

//circle class methods


circle::circle(float r, float x, float y)
  :point(x, y) //call base class constructor
{
  //default constructor
  m_r=r;

}
void circle::setradius(float r)
{
  m_r=r;
}

float circle::getradius() const
{
  return m_r;
}

float circle::getarea() const
{
  return(3.14159*m_r*m_r);
}

void main()
{
	point *pointPtr;
        point p(2.1, 3.2);

	circle *circlePtr;
	circle c(3.2, 1.7, 3.9);

	cout << "Point p: x=" << p.getx() << " y=" << p.gety() << endl;
	cout << "Circle c: radius=" << c.getradius() <<" x=" << c.getx() 
             << " y=" << c.gety() << " area=" << c.getarea() << endl << endl;

	pointPtr = (point *) &c;
        circlePtr = &c;

	cout << "Using point pointer to access circle base class information" << endl;
	cout << "Circle c: x=" << pointPtr->getx() 
             << " y=" << pointPtr->gety() << endl;

	cout << "Using circle pointer to access circle base class information" << endl;
	cout << "Circle c: x=" << circlePtr->getx() 
             << " y=" << circlePtr->gety() << endl;



}

