//program14.h
//Point class
//An example of ineritance

#ifndef SHAPES_H
#define SHAPES_H

//#include <stdio.h>
#include <iostream.h>

class point {

public:

	point(float x=0, float y=0);  //Default constructor

	void setpoint(float x, float y);
        float getx() const {return m_x;}
	float gety() const {return m_y;}

protected:   //accessible only by derived classes

	float m_x;
	float m_y;

};

class circle : public point {   //circle inherits from point

public:

	circle(float r, float x, float y); //default constructor
	void setradius(float r);
	float getradius() const;
	float getarea() const;

protected:
        float m_r;

};

#endif
