//program6.cpp
//Scoping in C++
//scoping.cpp


#include <iostream>

using std::cout;
using std::cin;
using std::endl;

void autolocal(void); //Function uses vars with automatic local scope
void staticlocal(void); //Fucntion  uses vars with static local scope
void global(void); //Function uses vars global scope

float pi=3.141;  //Global variable
float var=0;  //Global variable

main()
{
	float var=1.0; //Local variable to main
        cout << "Local var in outer scope of main is "
             << var << endl;

	cout << "using the unary scope resolution operator " << endl
             << "Global var is " << ::var << endl;

	{  
		//Start of a new block and scope
		float var=3.0;
		cout << "local var in inner scope of main is "
                     << var << endl;
	} 

	cout << "local var in outer scope of main is "
	     << var << endl << endl;

	autolocal(); 	//automatic local scope
	staticlocal(); 	//static local scope
	global(); 	//global scope
	autolocal(); 	//automatic local scope
	staticlocal(); 	//static local scope
	global(); 	//global scope

	cout << endl << "local var in main is " 
	     << var << endl;

	cout << "using the unary scope resolution operator " << endl
             << "Global var is " << ::var << endl;

	return 0;
} 

void autolocal(void) //Function uses vars with automatic local scope
{
	float var=5.0;  //initialised each time autolocal is called
	cout << "local var in autolocal is "
	     << var << " after entering autolocal" << endl;
	var+=pi;
	cout << "local var in autolocal is "
	     << var << " before leaving autolocal" << endl;

}

void staticlocal(void) //Function  uses vars with static local scope
{
	static float var=10.0;  //static initialisation only
                                //the first time that staticlocal is called

	cout << "local var in staticlocal is "
	     << var << " after entering staticlocal" << endl;
	var+=pi;
	cout << "local var in staticlocal is "
	     << var << " before leaving staticlocal" << endl;
}

void global(void) //Function uses vars global scope
{
	cout << "global var in global is "
	     << var << " after entering global" << endl;
	var+=pi;
	cout << "local var in global is "
	     << var << " before leaving global" << endl;
}
