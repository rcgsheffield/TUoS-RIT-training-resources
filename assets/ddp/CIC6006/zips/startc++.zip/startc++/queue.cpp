//program12.cpp
//A program for testing a Queue class

#include <iostream.h>
#include <stdlib.h>
#include <time.h>

#define MAXLEN 100
#define FALSE 0
#define TRUE  1


class qobj{
    public:

	qobj(int id=0);
	qobj *GetNextptr(){return m_nextptr;}
	void  SetNextptr(qobj *qn){m_nextptr=qn;}
	void  SetID(int id){m_i=id;}
        int   GetID(){return m_i;}
    private:
	int m_i;
        qobj *m_nextptr;
};

qobj::qobj(int id)
{
	m_i=id;
	m_nextptr=NULL;
}

class queue{
    public:

	queue();
	~queue();
	void enqueue(int id);
	qobj *dequeue();
	int  isEmpty(){return((!m_head && !m_tail)?FALSE:TRUE);}
	void displayqueue();
	int  length();
    private:
	qobj *m_head;
        qobj *m_tail;

};

queue::queue()
{
	m_head=NULL;
	m_tail=NULL;
}

queue::~queue()
{
	qobj *obj=NULL;
	cout << "Clearing queue." << endl;
	while(m_head)
	{
	      obj=dequeue();
	      if(obj)
		{
		 cout << "Deleting object id " << obj->GetID() << endl;
		 delete obj;
		}
	}
}

int queue::length()
{
	int len=0;
	qobj *obj;

	if(obj=m_head) len++;
	while(obj && obj != m_tail)
	{
	    len ++;
	    obj = obj->GetNextptr();
	}
	return len;

}

void queue::displayqueue()
{
	int ic=1;
	qobj *obj=m_head;

	cout << "There are " << length() << "ids in the queue." << endl;
	cout << "Current q is: " << endl;

	while(obj )
	{
	    cout << ic << " id is " << obj->GetID() << endl;
	    obj = obj->GetNextptr();            
	    ic++;
	}
}

void queue::enqueue(int id)
{
	qobj *obj = new qobj(id);

	if(m_head==NULL) 
		m_head=obj;
	else if(m_tail==NULL)
	{
		m_head->SetNextptr(obj);
		m_tail=obj;
	}
	else
	{
		m_tail->SetNextptr(obj);
		m_tail=obj;
	}

}

qobj *queue::dequeue()
{
	qobj *obj=m_head;
	if(obj)
	   m_head=obj->GetNextptr();

	return obj;
}

void FormJobQueue(queue &);
void ProcessJobs(queue &);
main()
{
	int i, njobs;
	int njobsdone;
	queue jobs;

	srand(time(NULL));  //Randomise list of ids...

	FormJobQueue(jobs);

	cout << "The initial queue is: " << endl;
	jobs.displayqueue();


	ProcessJobs(jobs);
	cout << "The latest queue is: " << endl;
	jobs.displayqueue();

	return 0;
}

//Must pass jobq in by reference
//if passed in by value the a local copy
// of jobq is created and deleted when
//exiting FormJobQueue
void FormJobQueue(queue &jobq)
{
 	int i, njobs;       
	//Form the job queue
	njobs=1+rand()%20;
	for(i=0; i<njobs; i++)
		jobq.enqueue(1+rand()%20);

}

void ProcessJobs(queue &jobq)
{
 	int i, njobsdone;
 	qobj *obj=NULL;
     
	//Determine how many queue items
        //processed and remove dequeue them
	njobsdone=rand()%jobq.length();
	cout << "Dequeue " << njobsdone << " finished jobs." << endl;
	for(i=0; i<njobsdone; i++)
	{
		obj=jobq.dequeue();     //Remove one job from the queue
		if(obj)
		{
  	      		cout << "Finished jobid " << obj->GetID() << endl;
	      		delete obj;
		}
	}

}



