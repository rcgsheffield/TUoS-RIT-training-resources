//program15.h
//Shape class
//An example of abstraction and polymorphism

#ifndef SHAPES_H
#define SHAPES_H


#include <iostream>

using std::cout;
using std::endl;

class shape {

public:
	virtual float area() const {return 0.0;}
	virtual float volume() const {return 0.0;}
	virtual void printShapeName()=0;  //pure virtual
};


class point : public shape{

public:

	point(float x=0, float y=0);  //Default constructor

	void setpoint(float x, float y);
        float getx() const {return m_x;}
	float gety() const {return m_y;}
        virtual void printShapeName(){cout << "Point: ";}

protected:   //accessible only by derived classes

	float m_x;
	float m_y;

};

class circle : public point {   //circle inherits from point

public:

	circle(float r, float x, float y); //default constructor
	void setradius(float r);
	float getradius() const;
	virtual float area() const {return(3.14159*m_r*m_r);}
        virtual void printShapeName(){cout << "Circle: ";}

protected:
        float m_r;

};

class square : public shape{

public:

	square(float x=0);  //Default constructor

	void setside(float x);
        float getside() const {return m_side;}
        virtual void printShapeName(){cout << "Square: ";}
	virtual float area() const {return(m_side*m_side);}

protected:   //accessible only by derived classes

	float m_side;


};


#endif
