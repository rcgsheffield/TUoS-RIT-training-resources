//program16.cpp
//Demonstration of the use of ANSI C and the
// template library

#include <fstream>
#include <string>
#include <set>
#include <algorithm>

using namespace std;

void doit(const char *, const char *);

int main()
{
	cout << "Reading namespace16.cpp " << endl
             << "Writing sorted16.txt " << endl;

	doit("namespace16.cpp", "sorted16.txt");
	
	return 0;
}

void doit(const char *in, const char *out)
{
	set<string>buf;
	string linBuf;
	ifstream inFile(in);
	while(getline(inFile, linBuf))
			buf.insert(linBuf);
	ofstream outFile(out);

	//string copy function in the ANSI library
	copy(buf.begin(),buf.end(),ostream_iterator<string>(outFile,"\n"));
}
