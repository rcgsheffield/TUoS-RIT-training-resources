//program9.cpp
//class creation and destruction using the stack example


#include <iostream.h>

class stack{
	public:
		stack(int sz=10);  //Constructor, initialise variables 
				   //allocate space
		~stack();          //Destructor deallocate space
	        void push(int value); //Push integer onto stack
	        int pop();
	public:
	        int m_size;  //Maximum capacity of the stack
		int m_count; //Index of the lowest unused position
	        int *m_stack; //A pointer to an array that holds the contents

};

stack::stack(int sz)
{
	m_size=(sz>0?sz:10);
	m_stack = new int[m_size];
	m_count=0;   //Initialise counter no elements o stack
}

stack::~stack()
{
	delete [] m_stack;
	cout << "Stack deleted." << endl;
}

void stack::push(int value)
{
	if(m_count<m_size)
	{
		m_stack[m_count]=value;
		m_count++;
	}
}

int stack::pop()
{
	if(m_count>0) m_count--;
	return m_stack[m_count];
}

void incstack(int t, stack &st);

int main()
{
	stack s1(17);
	stack *s2 = new stack(2);

	s1.push(5);
	s1.push(11);
	s1.push(12);

	s2->push(8);
	s2->push(7);
	
	incstack(5, s1);

	//pop items from the stack
	cout << "Popping stack s1 gives " << s1.pop() << endl;
	cout << "Popping stack s1 gives " << s1.pop() << endl;
	cout << "Popping stack s2 gives " << s2->pop() << endl;
	cout << "Popping stack s2 gives " << s2->pop() << endl;
	
	cout << "deleting stack s2: ";
	delete s2; 

	return 0;
}

void incstack(int t, stack &st)
{
	int i=0;
	int sz=st.m_count;
	
	for(i=0; i<sz; i++)
		*((st.m_stack)+i)+=t;


}
