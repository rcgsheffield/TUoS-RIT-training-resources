//program14.cpp
//Using namespaces example

#include <iostream>
using namespace std; //if this is omitted
                     //need to use the operator std::
                     //to access the iostream library functions
                     //such as cout.

namespace first
{
	int var=5;
}

namespace second
{
	double var=3.141;
}

int main()
{
	cout << "Namespace first " << first::var << endl;
	cout << "Namespace second " << second::var << endl;

	{
		using namespace first;
		std::cout << "Using namespace first " << var << std::endl;		
	}

	{
		using namespace second;
		std::cout << "Using namespace second " << var << std::endl;
	}

	return 0;
}
