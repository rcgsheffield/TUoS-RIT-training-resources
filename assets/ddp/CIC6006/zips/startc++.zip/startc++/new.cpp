//program4.cpp Dynamic memory allocation with the C++
//             new and delete operators
//new.cpp

#include <iostream>

using std::cout;
using std::cin;
using std::endl;

main()
{
	float *floatptr;
	float *floatarrayptr;
        int arraysize=10;
	int i;

	floatptr = new float(3.1415927);
	floatarrayptr = new float [arraysize];

	for(i=0; i<arraysize; i++)
		floatarrayptr [i] = *floatptr+i;

	cout << "floatptr is " << floatptr << "\n"
             << "*floatptr is " << *floatptr << "\n\n";

	cout << "Size of float is " << sizeof(float) << endl;

	cout << "i" << '\t' << "floatarrayptr" << '\t' 
             << "floatarrayptr[i]" << "\n";
	for(i=0; i<arraysize; i++)
		cout << i << '\t' << floatarrayptr+i
                     << "\t\t" << floatarrayptr [i] << "\n";

	delete floatptr;
	delete [] floatarrayptr;

	return 0;
}
