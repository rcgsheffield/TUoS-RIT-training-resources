//program17.cpp
//Demonstration of the use of ANSI C and the
// template library

#include <iostream.h>
#include <fstream.h>
#include <string.h>
#include <stdlib.h>


void doIt(const char *, const char *);
static void quit();
static void expandLinBuf(char*& , size_t& ,ifstream&  );
static void storeTok(char**& , size_t& , size_t& , const char* );

//This function is passed to qsort requires
//a decalration that it is a C type function
//which will be passed as a C function pointer
//to qsort
extern "C" int compare(const void * , const void * );


int main()
{
	cout << "Reading usingnamespace17.cpp " << endl
             << "Writing sorted17.txt " << endl;

	doIt("usingnamespace17.cpp", "sorted17.txt");
	
	return 0;
}

void doIt(const char* in , const char* out)
{
   /* allocate buffer with initial capacity */
   size_t bufSiz =1024;
   char** buf = (char**) malloc(sizeof(char*)*bufSiz);
   if (buf == 0) quit();
   size_t linCnt = 0;
   buf[linCnt] = 0;

   /* allocate line buffer as destination for read */
   size_t linBufSiz = 256; 
   char* linBuf = (char*) malloc(sizeof(char)*linBufSiz);
   if (linBuf == 0) quit();
   linBuf[0] ='\0'; 
   
   /* open input file */
   ifstream inFile(in);

   /********************************************************/
   /*                       read input                     */
   while (!(inFile.getline(linBuf,linBufSiz)).eof() && !inFile.bad())
   {/* while there is still input */
      expandLinBuf(linBuf,linBufSiz,inFile);
      storeTok(buf,linCnt,bufSiz,linBuf);
   }

   /* sort strings */
  
     qsort((void *)buf, linCnt ,sizeof(char*), compare); 
   /* open output file and write sorted strings to output file */
   ofstream outFile(out);
   for (size_t i = 0; i<linCnt;i++)
      outFile<<buf[i]<<endl;
}

int compare(const void *arg1, const void *arg2)
{
	return strcmp(*(char **)arg1, *(char **)arg2);

}

static void quit()
{ cerr << "memory exhausted" << endl;
  exit(1);
}

static void expandLinBuf(char*& linBuf, size_t& linBufSiz,ifstream& inFile )
{
      while (!inFile.eof()&&!inFile.bad()&&strlen(linBuf)==linBufSiz-1)
      { /* while line does not fit into string buffer */

        /* reallocate line buffer */
        linBufSiz += linBufSiz; 
        linBuf = (char*) realloc(linBuf,sizeof(char)*linBufSiz);
        if (linBuf == 0) quit();

        /* read more into buffer */
        inFile.getline(linBuf+linBufSiz/2-1,linBufSiz/2+1);
      }
}

static void storeTok(char**& buf, size_t& linCnt, size_t& bufSiz, const char* token)
{
         /* allocate memory for a copy of the token */
         size_t tokLen =strlen(token);
         buf[linCnt] = (char*) malloc(sizeof(char)*tokLen+1);
         if (buf[linCnt] == 0) quit();

         /* copy the token */
         strncpy(buf[linCnt++],token,tokLen+1);

         /* expand the buffer, if full */
         if (linCnt == bufSiz)
         {  bufSiz +=bufSiz;
            buf = (char**) realloc(buf,sizeof(char*)*bufSiz);
            if (buf == 0) quit();
         }
}
