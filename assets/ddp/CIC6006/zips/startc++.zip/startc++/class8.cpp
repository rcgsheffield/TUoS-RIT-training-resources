//program8.cpp
//C++ Class example illustrating
//class constructors and destructors

#include <iostream>
#include <cstring> //strcpy and strlen

using std::cout;
using std::endl;

class WrgComputeNode {
    public:

	WrgComputeNode(const char *sName ); //Constructor
	~WrgComputeNode(); //Destructor

	char *GetName(){ return m_sName; }

    private:
	char *m_sName;

};

WrgComputeNode::WrgComputeNode(const char *sName )
{
	m_sName = new char [strlen(sName)];
	strcpy(m_sName, sName);
}

//Delete memory that was allocated for the
//creation of the node name
WrgComputeNode::~WrgComputeNode()
{
	delete [] m_sName;
}

main()
{
	WrgComputeNode Sheffield("Titania");
	WrgComputeNode Leeds1("Maxima");
	WrgComputeNode York("Pascai");

	cout << "White Rose Grid Nodes." << endl;
	cout << "Sheffield grid node is " << Sheffield.GetName() << endl;
	cout << "Leeds grid node 1 is " << Leeds1.GetName() << endl;
	cout << "York grid node is " << York.GetName() << endl;

	return 0;
}
