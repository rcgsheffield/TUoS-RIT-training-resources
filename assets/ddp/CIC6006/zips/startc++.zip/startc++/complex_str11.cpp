//program11.cpp
//C++ Class example
//Passing an object to a function
//returning an object reference from a function

#include <iostream>

class Complex {


	friend ostream &operator<<(ostream & , Complex & );
	public:

	   Complex(float fre=0, float fim=0);

	   float GetRe() {return re;}  
	   float GetIm() {return im;}
	   void SetRe(float fre=0){re=fre;}
	   void SetIm(float fim=0){im=fim;}

	   void Set(float fre=0, float fim=0);
	   Complex &Add(Complex &x);
	   Complex &operator+(Complex &x);

	private:
	   float re;
	   float im;
};

Complex::Complex(float fre, float fim)
{
	re=fre;
	im=fim;
}

void Complex::Set(float fre, float fim)
{
	re=fre;
	im=fim;
}

Complex &Complex::Add(Complex &x)
{
	Complex result(re+x.GetRe(), im+x.GetIm());
	return result;
}

Complex &Complex::operator+(Complex &x)
{
	Complex result(re+x.GetRe(), im+x.GetIm());
	return result;
}

ostream &operator<<(ostream &output, Complex &comp)
{
	output << comp.GetRe() << "+i" << comp.GetIm() << " ";
	return output;
}


main()
{
	Complex a(1.0, 0.0);
	Complex b(0.0, 1.0);

	std::cout << "Complex number addition: " << std::endl;

	std::cout << "a is " << a << std::endl;
	std::cout << "b is " << b << std::endl;

	//Perform complex addition store result in C
	std::cout << "a+b is " << a+b << std::endl;

	return 0;
}


