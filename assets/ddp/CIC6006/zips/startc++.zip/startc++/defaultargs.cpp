//program5.cpp Using Default Arguments
//defaultargs.cpp

#include <iostream>

using std::cout;
using std::cin;
using std::endl;

//Return cuboid volume
inline float CuboidVolume(float length=1.0,
			  float width=1.0,
			  float height=1.0)
		{return(length*width*height);}

main()
{
	cout << "Default length, width and height \n"
             << "for a cuboid are 1, 1 and 1.\n";
        
	cout << "The default cuboid volume is " <<
             CuboidVolume() << " \n";

        cout << "The cuboid with length 10 has volume "
             <<   CuboidVolume(10) << endl;

       cout << "The cuboid with length 10 and width 5 has volume "
            <<    CuboidVolume(10, 5) << endl;

       cout << "The cuboid with length 10, width 5 and height 20 "
            <<   " has volume "
            <<   CuboidVolume(10, 5, 20) << endl;


	return 0;
}
