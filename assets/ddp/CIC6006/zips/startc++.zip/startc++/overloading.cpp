//program7.cpp
//Function overloading in C++
//overloading.cpp

#include <iostream>

using std::cout;
using std::cin;
using std::endl;

inline int square(int ival){return(ival*ival);}
inline double square(double dval){return(dval*dval);}

main()
{
	cout << "The square of int 3 is " 
	     <<  square(3) << endl << endl;

	cout << "The square of double 3.1 is " 
	     <<  square(3.1) << endl << endl;

	return 0;
}
