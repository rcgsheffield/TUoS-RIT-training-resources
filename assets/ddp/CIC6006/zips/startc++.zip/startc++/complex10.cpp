//program10.cpp
//C++ Class example
//Passing an object to a function
//returning an object reference from a function

#include <iostream>

using namespace std;

class Complex {
	public:

	   Complex(float fre=0, float fim=0);

	   float GetRe(){return re;}
	   float GetIm(){return im;}
	   void SetRe(float fre=0){re=fre;}
	   void SetIm(float fim=0){im=fim;}

	   void Display(){cout << re << "+i" << im << " ";}
	   void Set(float fre=0, float fim=0);
	   Complex &Add(Complex x);
	private:
	   float re;
	   float im;
};

Complex::Complex(float fre, float fim)
{
	re=fre;
	im=fim;
}

void Complex::Set(float fre, float fim)
{
	re=fre;
	im=fim;
}

Complex &Complex::Add(Complex x)
{
	Complex result(re+x.GetRe(), im+x.GetIm());
	return result;
}

int main()
{
	Complex a(1.0, 0.0);
	Complex b(0.0, 1.0);
	Complex c;

	cout << "Complex number addition: " << endl;

	cout << "a is ";
	a.Display();

	cout << endl << "b is ";
	b.Display();

	//Perform complex addition store result in C
	c=a.Add(b);
	
	cout << "\n\n" << "a+b is ";
	c.Display();
	cout << endl;

	return 0;
}


