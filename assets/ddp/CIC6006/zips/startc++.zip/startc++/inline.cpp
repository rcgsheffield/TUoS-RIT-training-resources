//program2.cpp
//Function Declarations and inline functions for C++

//inline.cpp

#include <iostream>

using std::cout;
using std::cin;


float cube(const float side);
inline float max(float x, float y){return (x>y?x:y);}
main()
{
	float fside;
	cout << "Enter cube dimension. ";
        cin >> fside;

	cube(fside);

	return 0;
}

float cube(const float side)
{
	float volume=side*side*side;

	cout<<"The cube of side "<< side << " has volume " << volume << ".\n";

	return volume;
}
