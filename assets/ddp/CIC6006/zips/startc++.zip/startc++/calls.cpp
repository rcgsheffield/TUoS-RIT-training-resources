//program3.cpp Examples of function calls 
// and call by reference using C++ references
//	     Call by pointer          
//           Call by value              	
//           Call by reference
//calls.cpp
#include <iostream>

using std::cout;
using std::cin;

float FuncByValue(float);
void  FuncByReference(float &);
void  FuncByPointer(float *);

main()
{
	float finval = 4;
	float finptr = 5;
        float finref = 6;
	float result;

        cout << "Original value of finval " << finval <<" \n";
        result=FuncByValue(finval);
	cout << "The function call result is " << result << "\n";
        cout << "The new value of finval after by value call is " 
             << finval <<" \n\n";

        cout << "Original value of finptr " << finptr <<" \n";
        FuncByPointer(&finptr);
        cout << "The new value of finptr after by value call is " 
             << finptr <<" \n\n";

        cout << "Original value of finref " << finref <<" \n";
        FuncByReference(finref);
        cout << "The new value of finref after by value call is " 
             << finref <<" \n\n";



	return 0;
}

float FuncByValue(float fval)
{
	return (fval=fval*fval); //callers argument not modified
}

void  FuncByReference(float &fvalptr)
{
	fvalptr = fvalptr * fvalptr;  // callers argument modified
}

void  FuncByPointer(float *fvalptr)
{
	*fvalptr = *fvalptr * *fvalptr;  //callers argument modified
}

