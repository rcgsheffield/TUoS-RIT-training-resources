//program15.h
//Shape class
//An example of abstarction and polymorphism

#include "absshape15.hpp"


//point class methods
point::point(float x, float y)
{
  //Default constructor
  m_x=x;
  m_y=y;
}

void point::setpoint(float x, float y)
{
  m_x=x;
  m_y=y;
}

//circle class methods


circle::circle(float r, float x, float y)
  :point(x, y) //call base class constructor
{
  //default constructor
  m_r=r;

}
void circle::setradius(float r)
{
  m_r=r;
}

float circle::getradius() const
{
  return m_r;
}

square::square(float x)
{
  //default constructor
  m_side=x;

}
void square::setside(float x)
{
  m_side=x;
}


int main()
{
	int i;

	shape *shapearray[3];
        point p(2.1, 3.2);
	circle c(3.2, 1.7, 3.9);
        square s(4.5);

	shapearray [0] = (shape *)&p;
	shapearray [1] = (shape *)&c;
	shapearray [2] = (shape *)&s;

	for(i=0; i<3; i++)
	{
	  cout << "Area of ";
          shapearray[i]->printShapeName();
          cout << shapearray[i]->area() << endl;
	}
	
	return 0;

}

