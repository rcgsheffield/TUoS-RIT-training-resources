Sample c programs for introduction to c programming course.

Compile each of the applications using
gcc progname.c -o executablename 
