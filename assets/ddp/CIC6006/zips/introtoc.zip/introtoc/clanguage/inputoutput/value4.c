#include <stdio.h>

int main()
{
	printf("I got %d% on my C exam!\n",98);

	return(0);
}

