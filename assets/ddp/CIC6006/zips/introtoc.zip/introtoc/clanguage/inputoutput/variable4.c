#include <stdio.h>

int main()
{
	float pi;

	pi = 22.00 / 7.0;
	printf("The ancients calculated PI as %f.\n",pi);

	return(0);
}

