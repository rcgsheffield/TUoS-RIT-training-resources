#include <stdio.h>

int main()
{
	int age;

	age = 32;
	printf("%s is %d years old.\n","Dan",age);
	printf("That's %d months!\n",age*12);

	return(0);
}

