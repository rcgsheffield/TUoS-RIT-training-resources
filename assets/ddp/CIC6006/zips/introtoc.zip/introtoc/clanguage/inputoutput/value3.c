#include <stdio.h>

int main()
{
	printf("You are a %s\n","programmer");

	return(0);
}

