#include <stdio.h>

int main()
{
	puts();

	return(0);
}

