#include <stdio.h>

int main()
{
	int x;

	for(x=0;x<10;x++)
		printf("%d\n",x);

	return(0);
}

