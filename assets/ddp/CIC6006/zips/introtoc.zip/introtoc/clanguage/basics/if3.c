#include <stdio.h>

int main()
{
	int a = -5;

	if(a > 0);
		printf("%d is a positive number.\n",a);
	
	return(0);
}

