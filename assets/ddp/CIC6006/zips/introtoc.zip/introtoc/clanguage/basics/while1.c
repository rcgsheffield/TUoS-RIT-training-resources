#include <stdio.h>

int main()
{
	int x;

	x = 1;
	while( x <= 10 )
	{
		printf("%d\n",x);
		x++;
	}

	return(0);
}

