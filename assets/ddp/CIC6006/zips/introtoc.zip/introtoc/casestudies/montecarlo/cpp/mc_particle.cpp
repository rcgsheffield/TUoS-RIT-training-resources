	#include "../include/mc_particle.hpp"
	
	Cmc_Particle::Cmc_Particle()
	{
		m_spin=1;		
	}
	
	Cmc_Particle::~Cmc_Particle()
	{
		
		
		
	}


	