

#include <iostream>


using std::cout;
using std::endl;



int main(int argc, char **argv)
{
	int status=0;
	
	//Hello world
	cout << "Hello from " << argv[0] << endl;
	
	return status;
}
